import React, { Component } from "react";
import { connect } from "react-redux";
import Cardsuser from "./cards/card-user"
import {getFoodsfromApi} from "../actions/foodsaction"
import Modalepanier from "./modal/modalpanier";
import { Card, Icon, Image, Button } from 'semantic-ui-react'
import {postCommandToApi} from '../actions/ordreaction'
import { Link } from "react-router-dom";
import Nav from "./nav"

class  Dashborduser  extends Component {
  constructor(){
    super();
  this.state = {
    style:"menu",
    menuStatus:"open"
  };
  this.handleClick = this.handleClick.bind(this);
};

handleClick() {
  switch(this.state.menuStatus)
  {
    case "open":
      this.setState({
        menuStatus:"close",
        style:"menu active"
      });
      break;
    case "close":
      this.setState({
        menuStatus:"open",
        style:"menu"
      });
      break;
  }        
}
    componentDidMount(){
        this.props.getfoods()
    }
  
  state = { open: false,panier:[] }
  show = (size) => () => this.setState({ size, open: true })
  close = () => this.setState({ open: false }) 

  render() {
    const {foods,Acheter} = this.props
    const { open, size } = this.state
    var options = {
      side: "left",
      effect: "diverge"
    };

    return (
      <div>
<Nav />
      
       

        <div className='cardcontainer'>

            {this.props.foods.map(el=>
             <Card>
             <Image src= {el.picture} wrapped ui={false} />
             <Card.Content>
                 <Card.Header>{el.name}</Card.Header>
               <Card.Meta>
                 <span className='date'>{el.price}</span>
               </Card.Meta>
               <Card.Description>
               {el.type}
               </Card.Description>
             </Card.Content>
             <Card.Content extra>
               <a>
               <Button.Group>
               <Link to ='/inscrit'> <Button inverted color='blue'> Commander</Button></Link>
           
                                        
                                        
           </Button.Group>
               </a>
             </Card.Content>
             
           </Card>
            
            
            )
            }
    
        </div>
      
     </div>
      
     
    );
  }
}
const mapStateToProps =(state)=>({
    foods: state.foods,
})
const  mapDispatchToProps = (dispatch) =>({
      getfoods :()=> dispatch(getFoodsfromApi()),
      addtocart: (el) => dispatch(postCommandToApi(el))
    
  })
  
  export default connect(mapStateToProps,mapDispatchToProps)(Dashborduser);

