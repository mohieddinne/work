import React, { Component } from "react";
import { connect } from "react-redux";
import Cards from "./cards/card"
import {getFoodsfromApi} from "../actions/foodsaction"
import { Button,Grid ,Image,Checkbox,Menu, Segment, Header} from 'semantic-ui-react'
import Modaladd from "./modal/modaladd";
import { Link } from "react-router-dom";

class Dashbordadmin extends Component {
  constructor(){
    super();
  this.state = {
    style:"menu",
    menuStatus:"open"
  };
  this.handleClick = this.handleClick.bind(this);
};
handleSearchType=(e) => {
  this.setState({searchType:e.target.value.toUpperCase()})
  var regex = new RegExp(e.target.value.toUpperCase());
  this.setState({foods:this.props.foods.filter(el => regex.test(el.name.toUpperCase()))})
   
}
handleClick() {
  switch(this.state.menuStatus)
  {
    case "open":
      this.setState({
        menuStatus:"close",
        style:"menu active"
      });
      break;
    case "close":
      this.setState({
        menuStatus:"open",
        style:"menu"
      });
      break;
  }        
}

    componentDidMount(){
        this.props.getfoods()
    }
    state = { open: false }
    show = (size) => () => this.setState({ size, open: true })
    close = () => this.setState({ open: false })

  render() {
    const { open, size } = this.state
    var options = {
      side: "left",
      effect: "diverge"
    };

    return (
      <div >
      

        
         <Button color='blue'onClick={this.show('mini')}>ajouter un plat</Button>
         <Link to ='/inscrit'><Button>logout</Button></Link>
         
          {/* <div><input handleSearch ={this.handleSearchType} search = {this.state.searchType}/></div> */}
  
        
        <div className='cardcontainer'>
        <Modaladd close={this.close}  size={this.state.size} open={this.state.open}/>
            {this.props.foods.map(el=> <Cards el={el}/>)
            }
  
        </div>
      
      </div>
    );
  }
}
const mapStateToProps =(state)=>({
    foods: state.foods,
})
const  mapDispatchToProps = (dispatch) =>({
      getfoods :()=> dispatch(getFoodsfromApi()),
    
  })
  
  export default connect(mapStateToProps,mapDispatchToProps)(Dashbordadmin);

