export const ADDUSER = 'ADDUSER';
export const DELETE_USERS = 'DELETE_USERS';
export const GETUSER = 'GETUSER';
//get foods
export const GET_ALL_FOODS ='GET_ALL_FOODS';
export const DELETE_FOOD = 'DELETE_FOOD';
export const EDIT_FOOD ='EDIT_FOOD';

export const ADD_FOOD ='ADD_FOOD'
export const GET_ALL_ORDERS = 'GET_ALL_ORDERS';
export const  GETCMD = ' GETCMD'
export const ADDCMD = 'ADDCMD'
export const DELETECMD = 'DELETECMD'