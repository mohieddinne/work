import React from "react";
import { useDispatch } from "react-redux";
import Tooltip from "@material-ui/core/Tooltip";
import CircularProgress from "@material-ui/core/CircularProgress";
import IconButton from "@material-ui/core/IconButton";
import Icon from "@material-ui/core/Icon";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import { useTranslation } from "react-i18next";
import * as Actions from "../../store/action";
import * as MainActions from "app/store/actions";
import gql from "graphql-tag";
import { useMutation } from "@apollo/react-hooks";

const gQl = gql`
  mutation deleteClientGroup($id: ID!) {
    deleteClientGroup(id: $id)
  }
`;

function DeleteButton({ id, count }) {
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const [exec, { loading }] = useMutation(gQl);

  const handleClose = () => dispatch(MainActions.closeDialog());

  const handleDelete = () => {
    exec({ variables: { id } })
      .then(() => {
        dispatch(Actions.deleteItem(id));
        handleClose();
      })
      .catch((err) => {
        if (process.env.NODE_ENV !== "production") console.log(err);
      });
  };
  // const data = useSelector(({ ClientsGroupsApp }) => {
  //   return ClientsGroupsApp.data || [];
  // });
  // const item = data.filter((e) => e.id === id);

  // console.log("item", item[0].clientCount);
  // React.useEffect(() => {
  //   console.log("client", data[0].clientCount);
  //   console.log("client", data);
  // }, [data]);
  // Create the dialog object
  const handleClick = () => {
    const dialog = {
      title: t("gApp:you_are_deleting_group"),
      maxWidth: "sm",
      content: (
        <Typography class="flex flex-col">
          <span class="text-gray-900 text-center  px-4 py-2 m-2">
            {t("gApp:you_are_deleting_group_Ques")}{" "}
          </span>
          <span class="text-gray-900 text-center  px-4 py-2 m-2">
            {" "}
            {+" " + count} {t("gApp:customer") + "  !  "}
          </span>

          {t("gApp:you_are_deleting_group_desc")}
        </Typography>
      ),
      actions: [
        <Button
          onClick={handleClose}
          color="primary"
          variant="contained"
          disableElevation
          autoFocus
          disabled={loading}
        >
          {t("button.cancel")}
        </Button>,
        <Button
          onClick={handleDelete}
          color="primary"
          variant="outlined"
          autoFocus
          disabled={loading}
        >
          {loading && <CircularProgress size={24} />}
          {t("button.i_confirm")}
        </Button>,
      ],
    };
    // dispatch it
    dispatch(MainActions.openDialog(dialog));
  };

  return (
    <Tooltip title={t("gApp:delete_the_group")}>
      <span>
        <IconButton onClick={handleClick} disabled={loading}>
          {loading ? (
            <CircularProgress size={24} />
          ) : (
            <Icon>delete</Icon>
          )}
        </IconButton>
      </span>
    </Tooltip>
  );
}

export default DeleteButton;
