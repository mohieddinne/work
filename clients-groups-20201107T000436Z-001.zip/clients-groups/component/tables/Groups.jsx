import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import * as Actions from "../../store/action";
import { useQuery } from "@apollo/react-hooks";
import { gql } from "apollo-boost";
import GroupsUI from "./GroupsUI";

const query = gql`
  query clientGroups {
    clientGroups {
      id
      name
      color
      clientCount
    }
  }
`;

function List() {
  const dispatch = useDispatch();

  const { data, loading, error } = useQuery(query);

  useEffect(() => {
    if (data && Array.isArray(data.clientGroups)) {
      dispatch(Actions.setGroups(data.clientGroups));
    }
  }, [data]);
  if (error) return "<Error />"; //TODO

  return <GroupsUI loading={loading} />;
}

export default List;
