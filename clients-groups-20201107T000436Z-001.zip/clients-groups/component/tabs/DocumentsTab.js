import React from "react";
import { useSelector, useDispatch } from "react-redux";

import { TextFieldFormsy } from "@fuse";
import { useTranslation } from "react-i18next";
import Formsy from "formsy-react";
import * as actions from "../../store/action";
import Typography from "@material-ui/core/Typography";

function DetailsTab({ formRef }) {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const canSubmit = useSelector(
    ({ ClientsGroupsApp }) => ClientsGroupsApp.form.canSubmit
  );
  const isEditable = useSelector(
    ({ ClientsGroupsApp }) => ClientsGroupsApp.form.isEditable
  );
  const data = useSelector(
    ({ ClientsGroupsApp }) => ClientsGroupsApp.form.data || null
  );

  return (
    <>
      <Formsy
        ref={formRef}
        onValid={() => {
          if (!canSubmit) {
            dispatch(actions.setSubmittable(true));
          }
        }}
        onInvalid={() => {
          if (canSubmit) {
            dispatch(actions.setSubmittable(false));
          }
        }}
        className="p-16 sm:p-24 max-w-2xl"
      >
        <TextFieldFormsy
          id="id"
          name="id"
          type="hidden"
          value={data && data.id ? data.id : null}
        />
        {isEditable ? (
          <TextFieldFormsy
            className="mt-8 mb-16"
            label={t("name")}
            autofocus
            validationErrors={{
              required: t("error.form.required"),
            }}
            id="name"
            name="name"
            fullWidth
            variant="outlined"
            value={data && data.name ? data.name : null}
          />
        ) : (
          <div>
            <Typography
              color="inherit"
              variant="subtitle2"
              component="div"
            >
              {data && data.name ? data.name : null}{" "}
            </Typography>

            <div>
              <Typography
                color="inherit"
                variant="subtitle2"
                component="div"
              >
                Nombre de groupe :{" "}
                {data && data.clientCount ? data.clientCount : null}{" "}
              </Typography>
            </div>
          </div>
        )}

        {isEditable ? (
          <TextFieldFormsy
            className="mt-8 mb-16"
            label={t("color")}
            id="color"
            name="color"
            fullWidth
            variant="outlined"
            value={data && data.color ? data.color : null}
          />
        ) : (
          <div>
            <Typography
              color="inherit"
              variant="subtitle2"
              component="div"
            >
              {data && data.color ? data.color : null}{" "}
            </Typography>
          </div>
        )}
      </Formsy>
    </>
  );
}

export default DetailsTab;
