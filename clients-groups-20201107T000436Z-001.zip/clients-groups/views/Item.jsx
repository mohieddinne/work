import React, { useState, useEffect } from "react";
import CatuFilePageCarded from "@CatuFramework/components/PageLayouts/carded/CatuFilePageCarded";
import Tabs from "@material-ui/core/Tabs";
import withReducer from "app/store/withReducer";
import { useDispatch } from "react-redux";
import reducer from "../store/reducer";
import * as Actions from "../store/action";
import { useTranslation } from "react-i18next";
import HeaderForm from "@CatuFramework/components/HeaderForm";
import { showMessage } from "app/store/actions";
import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import DocumentsTab from "../component/tabs/DocumentsTab";

function DocumentFormPage(props) {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const [formRef, setFormRef] = useState(null);
  const list = useSelector(
    ({ ClientsGroupsApp }) => ClientsGroupsApp.data || []
  );

  const routeParams = useParams();

  const url = "/app/clients/groups";

  useEffect(() => {
    const itemId =
      routeParams.itemId !== "new"
        ? parseInt(routeParams.itemId)
        : null;
    if (!itemId) {
      dispatch(Actions.updateFormData(null));
    } else {
      const item = list.find((e) => parseInt(e.id) === itemId);
      console.log("item", item);
      if (!item && itemId) {
        // change the url if the element is not found but there is an id
        //TODO call the get by id

        const found = list.find((element) => element.id === list.id);

        dispatch(Actions.updateFormData(found));
        console.log("found", found);
      }
      if (item) {
        dispatch(Actions.setEditable(false));
        dispatch(Actions.updateFormData(item));
      }
    }
  }, []);

  const toggleEditable = () => {
    dispatch(Actions.setEditable(true));
  };

  const handleResponse = ({ response, error, isNew, exit }) => {
    let variant = "success";
    if (error) {
      variant = "error";
    }
    dispatch(
      showMessage({
        message: t(`gApp:${variant}.${isNew ? "create" : "update"}`, {
          name: response && response.name,
        }),
        autoHideDuration: 3000,
        variant, //success error info warning null
      })
    );
    exit && props.history.push(url || "/groupe");
  };
  const handleSubmit = (exit) => {
    dispatch(
      Actions.submit(formRef.getModel(), handleResponse, exit)
    );
  };

  return (
    <CatuFilePageCarded
      classes={{
        toolbar: "p-0",
        header: "min-h-72 h-72 sm:h-136 sm:min-h-136",
      }}
      header={
        <HeaderForm
          strings={{
            defaultTitle: t("gApp:new"),
            caption: t("gApp:new_group"),
            list_name: t("gApp:group", { count: 2 }),
          }}
          url={url}
          submitAction={handleSubmit}
          reduxStore="ClientsGroupsApp"
          options={{
            showIconEditor: false,
          }}
          toggleEditable={toggleEditable}
        />
      }
      content={<DocumentsTab formRef={setFormRef} />}
      innerScroll
    />
  );
}

export default withReducer(
  "ClientsGroupsApp",
  reducer
)(DocumentFormPage);
